from urllib import parse

import requests
from bs4 import BeautifulSoup

source = requests.get("https://www.melon.com/chart/index.html").text
soup = BeautifulSoup(source, "html.parser")

print(source)
print(soup)

source2 = requests.get("https://www.naver.com/").text
soup2 = BeautifulSoup(source2, "html.parser")

print(soup2)
print(source2)

#
#멜론 순위 타이틀
melon = soup.select(" div.wrap")

melon_title = soup.select(" .div.ellipsis.rank01")
#멜론이미지
melon_img = soup.select("span.bg_album_frame") #멜론이미지


print(melon)
print(source)
print(melon_title)

print('------------')
index = 0
for key in melon:
    index += 1
    print(key.select_one("div.wrap_song_info"))

#1 특정한 사이트에서 크롤링을 해서 file.txt에 넣음. 버튼을 만들어서 눌러서 처리
#2

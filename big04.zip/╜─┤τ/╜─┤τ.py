from 음식.주문 import *

print("내가 주문한 ", end='')
myCof = Coffee("아이스아메리카노", 2500)
print(myCof)
myCak = Cake("초코케이크", 4000)
print(myCak)
myCak.한입만()
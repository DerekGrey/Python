from tkinter import *
from tkinter.messagebox import *

yesterday = ['홍길동', '박길동', '김길동']
today = ['홍길동', '정길동', '이길동']

#1 어제 / 오늘 각 각 파티에 참석한 명단 출력
print("어제 파티에 참석한 사람은 : ", end=''), print(yesterday)
print("오늘 파티에 참석한 사람은 : ", end=''), print(today)

set_yes = set(yesterday)
set_tod = set(today)

print("어제/오늘 모두 참석한 사람은 : ", end=''), print(set_yes.intersection(set_tod))
print("어제/오늘 참석한 사람은 : ", end=''),print(set_yes.union(set_tod))
party_list = list(set_yes.union(set_tod))
print(type(party_list))
print("어제/오늘 참석파티 인원수는 : ", end=''), print(len(party_list))

print('----------------문자입력-------------')
data = str(input('문장을 입력 >>'))
print("입력한 문장은 :", data)
print("전체글자수: ", len(data))
print("전체 단어 : ")
test_data = data.split(' ')
print("나는 테스트 데이터 : ", test_data)
list_data = list(data)
print(list_data)
sp_data = data.split(' ')
print(sp_data)

for x in sp_data:
    print(x, str(len(x)), '글자')


print('--------인기투표 시스템-----')
print('--------------')
print('1)아이유 2)BTS 3)유재석 4)종료')
print('----------')

vote = dict()

t_vote = {'아이유' : 0, 'BTS' : 0, '메롱' : 0}
print(t_vote)
vote['아이유'] = 0
vote['BTS'] = 0
vote['유재석'] = 0
print(vote)
print(type(vote))

for x in range (0,10):
    vote_data = input('입력>>')
    if vote_data == '1':
        vote['아이유'] = vote['아이유'] + 1
    elif vote_data == '2':
        vote['BTS'] = vote["BTS"] + 1
    elif vote_data =='3':
         vote['유재석'] = vote['유재석'] + 1
    elif vote_data =='4':
        print('종료됨')
        break
    else:
        print("잘못 입력하심, 1~4에서 눌러주세요.")
print(vote)

#if 는 하나 충족하면 바로 그 라인 종료
#elif 는 if가 충족해도, 실행함 ex) if VIP 할인, if coupon 할인
#웹


fruit = ['apple', 'banana', 'melon']

def file_write():
    f = open('fruit.txt', 'w')
    for x in fruit:
        f.write(x + '\n')
    f.close()


def file_read():
    f = open('fruit.txt', 'r')
    result = []
    for x in range(0,3):
        data = f.readline()
        data2 = data.replace('\n','')
        print(data2, end=' ')

    f.close()

w = Tk()
w.geometry('500x400')
w.config(bg='skyblue')
button = Button(w, text = '파읽읽기', command=file_read)
button2 = Button(w, text = '파일저장', command=file_write)
button.pack()
button2.pack()

w.mainloop()
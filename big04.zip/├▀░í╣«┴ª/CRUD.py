from tkinter import *
from tkinter.messagebox import *
from 추가문제.DAO import *


def add():
    info = []
    get_id = id_text.get()
    get_pw = pw_text.get()
    get_name = name_text.get()
    get_tel = tel_text.get()
    info.append(get_id)
    info.append(get_pw)
    info.append(get_name)
    info.append(get_tel)
    print(info)
    insert(info)

def all():



def search():
    get_id = str(id_text.get())
    result = select(get_id)
    print(result)
    f = open('info.txt', 'w')
    for x in result:
        f.write(x)
    f.close()

def modify():
    get_id = id_text.get()
    get_pw = pw_text.get()
    update(get_pw, get_id)

def remove():
    get_id = id_text.get()
    result = delete(get_id)
    print(result)


w = Tk()
w.geometry('500x700')
w.config(bg='white')

id_label = Label(w, text='아이디',
                    font = ('맑은 고딕', 30),  # 튜플로 만듦
                    bg = 'white',
                    fg = 'black')

pw_label = Label(w, text='비번',
                    font=('맑은 고딕', 30),  # 튜플로 만듦
                    bg='white',
                    fg='black')

name_label = Label(w, text='이름',
                    font = ('맑은 고딕', 30),  # 튜플로 만듦
                    bg = 'white',
                    fg = 'black')
tel_label = Label(w, text='번호',
                    font = ('맑은 고딕', 30),  # 튜플로 만듦
                    bg = 'white',
                    fg = 'black')
#텍스트 필드영역

id_text = Entry(w, #날짜
                 font=('맑은 고딕', 30),  # 튜플로 만듦
                 bg='yellow',
                 fg='red'
                )
pw_text = Entry(w, #날짜
                 font=('맑은 고딕', 30),  # 튜플로 만듦
                 bg='yellow',
                 fg='red'
                )
name_text = Entry(w, #날짜
                 font=('맑은 고딕', 30),  # 튜플로 만듦
                 bg='yellow',
                 fg='red'
                )
tel_text = Entry(w, #날짜
                 font=('맑은 고딕', 30),  # 튜플로 만듦
                 bg='yellow',
                 fg='red'
                )

icon = PhotoImage(file='naver.png')
#메인버튼 위치
mButton = Button(w, image=icon)
#파일로저장
insert_button = Button(w, command=add, text="입력")
insert_button.config(bg="skyblue")
#파일로읽기
read_button = Button(w, command=search, text="읽기")
read_button.config(bg="skyblue")
#업데이트
update_button = Button(w, command=modify, text="업데이트")
update_button.config(bg="skyblue")
#딜리트
delete_button = Button(w, command=remove, text="딜리트")
delete_button.config(bg="skyblue")

#버튼자리잡기
mButton.pack() #자리잡기
id_text.pack()
pw_text.pack()
name_text.pack()
tel_text.pack()
insert_button.pack()
read_button.pack()
update_button.pack()
delete_button.pack()


w.mainloop() #셋비저블
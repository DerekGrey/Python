from tkinter import *
from tkinter.messagebox import *
import pymysql


def insert():
    #입력값 가지고 오기
    get_date = date_text.get()
    get_title = title_text.get()
    get_content = content_text.get()

    info = []
    info.append(get_date + ',' + get_title + ',' + get_content)
    print(info)
    showinfo('당신이 입력한 날짜 ', get_date)
    showinfo('당신이 입력한 제목 ', get_title)
    showinfo('당신이 입력한 내용 ', get_content)

    f = open('info.txt', 'w')
    for x in info:
        f.write(x)
    f.close() #한줄로 뭉쳐 넣음

def read():
    f = open('info.txt', 'r')
    while True:
        data = f.readline()
        data2 = data.replace('\n', '')
        print(data2, end=' ')
        if not data2: break
    f.close()

def update():
    f = open('info.txt', 'r')
    while True:
        data = f.readline()
        data2 = data.replace('\n', '')
        print(data2, end=' ')
        if not data2: break

    #읽어오기 끝
    get_date = date_text.get()
    get_title = title_text.get()
    get_content = content_text.get()

    info = []
    #배열에 계속 추가
    info.append(get_date + ',' + get_title + ',' + get_content)
    s = open(info.txt, 'w')
    for i in info:
        f.write(i)
    print(info)
    f.close()



w = Tk()
w.geometry('500x700')
w.config(bg='white')

date_label = Label(w, text='날짜',
                    font = ('맑은 고딕', 30),  # 튜플로 만듦
                    bg = 'white',
                    fg = 'black')

title_label = Label(w, text='제목',
                    font=('맑은 고딕', 30),  # 튜플로 만듦
                    bg='white',
                    fg='black')

content_label = Label(w, text='내용',
                    font = ('맑은 고딕', 30),  # 튜플로 만듦
                    bg = 'white',
                    fg = 'black')
#텍스트 필드영역

date_text = Entry(w, #날짜
                 font=('맑은 고딕', 30),  # 튜플로 만듦
                 bg='yellow',
                 fg='red'
                )
title_text = Entry(w, #날짜
                 font=('맑은 고딕', 30),  # 튜플로 만듦
                 bg='yellow',
                 fg='red'
                )
content_text = Entry(w, #날짜
                 font=('맑은 고딕', 30),  # 튜플로 만듦
                 bg='yellow',
                 fg='red'
                )

icon = PhotoImage(file='naver.png')
#메인버튼 위치
mButton = Button(w, image=icon)
#파일로저장
insert_button = Button(w, command=insert, text="파일로 저장")
insert_button.config(bg="skyblue")
#파일로읽기
read_button = Button(w, command=read, text="파일 읽기")
read_button.config(bg="skyblue")
#업데이트
update_button = Button(w, command=read, text="업데이트 버튼")
update_button.config(bg="skyblue")

#버튼자리잡기
mButton.pack() #자리잡기
date_label.pack()
date_text.pack()
title_label.pack()
title_text.pack()
content_label.pack()
content_text.pack()
insert_button.pack()
read_button.pack()
update_button.pack()


w.mainloop() #셋비저블
import pymysql

#mySQL Connection 연결


#SQL문 실행, id, pw, name, tel
def all():
    conn = pymysql.connect(host='localhost', port=3708, user='root', password='1234', db='big', charset='utf8')
    curs = conn.cursor()
    sql = "select * from member"
    curs.execute(sql) #쿼리문 실행
    rows = curs.fetchall()
    # 데이타 fetch
    for i in rows:
        print(i)
    # connection 닫기
    conn.close()

def select(id): # 'id' 파라미터 변수 들어와야 함
    conn = pymysql.connect(host='localhost', port=3708, user='root', password='1234', db='big', charset='utf8')
    curs = conn.cursor()
    sql = "select * from member where id =%s" #%s 조건에 대한 변수가 들어와야 함.
    curs.execute(sql,id) #쿼리문 실행 (sql, id)
    rows = curs.fetchall()
    # 데이타 fetch
    for i in rows:
        print(i)
    # connection 닫기
    conn.close()
    return str(rows)

def insert(member): # 'id' 파라미터 변수 들어와야 함
    conn = pymysql.connect(host='localhost', port=3708, user='root', password='1234', db='big', charset='utf8')
    curs = conn.cursor()
    sql = "insert into member values (%s, %s, %s, %s)" #%s 조건에 대한 변수가 들어와야 함.
    curs.execute(sql,(member)) #쿼리문 실행 (sql, id)
    conn.commit()
    conn.close()

def delete(id): # 'id' 파라미터 변수 들어와야 함
    conn = pymysql.connect(host='localhost', port=3708, user='root', password='1234', db='big', charset='utf8')
    curs = conn.cursor()
    sql = "delete from member where id = %s" #%s 조건에 대한 변수가 들어와야 함.
    curs.execute(sql, id) #쿼리문 실행 (sql, id)
    # 데이타 fetch
    conn.commit()
    conn.close()

def update(pw,id): # 'id' 파라미터 변수 들어와야 함
    conn = pymysql.connect(host='localhost', port=3708, user='root', password='1234', db='big', charset='utf8')
    curs = conn.cursor()
    sql = "update member set pw =%s where id =%s" #%s 조건에 대한 변수가 들어와야 함.
    curs.execute(sql, (pw, id)) #쿼리문 실행 (sql, id)
    conn.commit()
    conn.close()



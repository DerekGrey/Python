class Coffee:
    #멤버변수
    menu = ''
    price = 0

    def __init__(self, menu, price):
        self.menu = menu
        self.price = price

    def __str__(self):
        return "커피 메뉴는 : " + self.menu + " 이며, 가격은 : " + str(self.price)

    def drink(self):
        print("커피를 마신다.")

    def sleeve(self):
        print("슬리브를 씌운다.")

class Cake:
    #멤버변수
    menu = ''
    price = 0

    def __init__(self, menu, price):
        self.menu = menu
        self.price = price

    def __str__(self):
        return "케이크 메뉴는" + self.menu + " 이며, 케이크 가격은 : " + str(self.price)

    def fork(self):
        print("포크로 케이크를 집는다.")

    def 한입만(self):
        print("한입충이라 한입만 달라한다.")

if __name__ == '__main__':
    cupOfcof = Coffee('아이스아메리카노', 3000)
    print(cupOfcof)
    tCof = Coffee("핫 아메리카노", 2000)
    print(tCof)
    tCof.sleeve()

    caky = Cake("오레오", 25000)
    print(caky)
    caky.한입만()
from django.apps import AppConfig


class CalendarTestConfig(AppConfig):
    name = 'calendar_test'

from django.http import HttpResponse
from django.shortcuts import render

# Create your views here.
from django.urls import reverse_lazy
from django.views.generic import ListView, CreateView, DetailView, UpdateView, DeleteView

from bookmark.models import BookMark
from member.models import Member


#Create
class MemberCreate(CreateView):  # CreateView 기능 상속, Alt+ Enter
    model = Member  #모델에 있는걸 넣어주는거야!
    fields = ['num', 'id', 'pw', 'name']  # insert할 필드들(=항목들)
    # Create할때는 입력하는 template이 필요함, **지정!**
    template_name_suffix = '_create'  # bookmark_create로 넘어온건 자동으로 호출되서 filed값 안에 넣어버림. 신기한구조
    # html_create임얌

    # 렌더링
    # 성공했으면 어느 페이지로 연결할지 설정
    # 호출했던 페이지의 위치에 상관없이 list라고 명명된 페이지를 호출해준다.
    success_url = reverse_lazy('mList')  # 성공하면 이 페이지(='list)로 넘어감! Alt Enter

#List
class MemberList(ListView):
    model = Member
    #template_name = 'templates/member/member_list.html'

#Update
class MemberUpdate(UpdateView):
    model = Member
    fields = ['num', 'id', 'pw', 'name']
    template_name_suffix = '_update'
    success_url = reverse_lazy('mList')

#Delete
class MemberDelete(DeleteView):
    model = Member
    success_url = reverse_lazy('mList')

#Detail
class MemberDetail(DetailView):
    model = Member
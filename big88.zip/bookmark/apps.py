from django.apps import AppConfig


class BookmarkConfig(AppConfig):
    name = 'bookmark'

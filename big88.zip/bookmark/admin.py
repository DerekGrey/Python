from django.contrib import admin

# Register your models here.
from bookmark.models import BookMark

admin.site.register(BookMark)
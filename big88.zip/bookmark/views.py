from django.http import HttpResponse
from django.shortcuts import render

# Create your views here.
from django.urls import reverse_lazy
from django.views.generic import ListView, CreateView, DeleteView, UpdateView, DetailView

from bookmark.models import BookMark

class BookDetail(DetailView):
        model = BookMark
        #상속받아 bookmark_detail.htmll 으로 자동넘김

class BookDelete(DeleteView):
        model = BookMark
        success_url = reverse_lazy('list') #리턴url을 지정해줘

class BookUpdate(UpdateView):
        model = BookMark
        fields = ['site_name', 'url']
        template_name_suffix = '_update'
        success_url = reverse_lazy('list') #리턴url을 지정해줘

class BookCreate(CreateView): #CreateView 기능 상속, Alt+ Enter
        model = BookMark #
        fields = ['site_name', 'url'] #insert할 필드들(=항목들)
        #Create할때는 입력하는 template이 필요함, **지정!**
        template_name_suffix = '_create' #bookmark_create로 넘어온건 자동으로 호출되서 filed값 안에 넣어버림. 신기한구조
        #html_create임얌

        # 렌더링
        #성공했으면 어느 페이지로 연결할지 설정
        #호출했던 페이지의 위치에 상관없이 list라고 명명된 페이지를 호출해준다.
        success_url = reverse_lazy('list') #성공하면 이 페이지(='list)로 넘어감! Alt Enter

def index(request, name, tel):
        return HttpResponse('received name : ' + name + '<br>' + \
                            'received tel : ' + tel)

class BookList(ListView):
        model = BookMark #리스트뷰가 가진 멤버변수 model을 내 리스트로 만들기 위해, 오버라이트하는 과정임.
                         #model 은 자동화로 템플릿에서 읽겠금, 알아서 장고가 세팅되어있음.
        paginate_by = 5 # 한 페이지에 5개씩 페이징(쇼) 해주겠다.

        #template_name = "templates/bookmark/bookmark_list.html"
        #template 파일명 : 모델명_list.html --> List기 때문에 모델명_List로 되어있음.
        #모델명은 소문자.
        #CRUD의 다른기능이라면 _Create
        #다르게 만들거면 template_name = '' 이렇게 만드러줘야함.
#다른 클래스 view(=controller)를 만들려면,
# class BookSelect(SelectView):
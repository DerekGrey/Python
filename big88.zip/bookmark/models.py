from django.db import models

# Create your models here.
# ORM ( 언어의 변수들과 RDB 테이블 항목들과의 맵핑)
# DTO/VO 만들지 않음. 장고 자동 생성
from django.urls import reverse


class BookMark(models.Model): #상단부 import models의 기능을 상속받음 -> ORM 맵핑을 위해 (이미 맵핑기능을 가지고 있음)
        #파이썬의 변수이자, DB 테이블의 칼럼명과 동일
        site_name = models.CharField(max_length=100, primary_key=True) #Django에선 primary key를 항상 생성, default= 라고 하면, default값 뭐로 지정함.
        url = models.URLField('site url') #이것도 클래스임 URL 필드
        #참고 : http://pythonstudy.xyz/Python/Django

        #To_String( 접근연산자 BookMark)라고 한다면 이거 다 찍어서 반환해줌
        def __str__(self):
            return '사이트명 : ' + self.site_name + \
             ' 인터넷 주소 : ' + self.url

        #success_lazy 대신 미리 return 경로를 설정해주는 것임. 모델에서 이 경로 설정하면, views에서 경로설정할 필요없음
        def get_absolute_url(self):
            return reverse('detail', args=[str(self.site_name)]) #self.site_name arguement 값을 detail 페이지에 넘긴다.
            #int 도 항상 str로 바꿔서 넘겨 왜냐면 1+1 이면 -> 11이 아니라 2가 되잖아.


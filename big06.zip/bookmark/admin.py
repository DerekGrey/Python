from django.contrib import admin

# Register your models here.
# 관리자 계정만 등록

from .models import BookMark
## 관리자모드에서 관리할 테이블을 등록
admin.site.register(BookMark)
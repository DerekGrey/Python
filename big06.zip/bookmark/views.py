from django.http import HttpResponse
from django.shortcuts import render

# Create your views here.
# 파이썬의 view는 Controller의 역할.
# app(패키지마다) view를 만들어준다.

#간단한 CRUD를 클래스로 만들어놓음
from django.views.generic import ListView

from bookmark.models import BookMark


#View는 요청에 따른 컨트롤러의 역할을 한다.
#기본적으로는 함수로 정의하할 수 있고
#부가적으로는 클래스로 정의가능
class BookmarkListView(ListView): #괄호안은 상속, DB에서 리스트를 가져옴.
    model = BookMark #DB값을 가져와서 변수안에 넣음.
    template_name = "templates/bookmark/bookmark_list.html"

def index(request):
    return HttpResponse("Welcome Django!")

def index2(request):
   site = HttpResponse("<a href=/admin>관리자모드로</a><br>"  + \
                        "<a href=/bookmark/>북마크로</a><br>"  + \
                        "<a href=/bookmark3/>북마크리스트로</a>")
   return HttpResponse(site)
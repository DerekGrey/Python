from django.db import models

# Create your models here.
# ORM

class BookMark(models.Model): # 상속받음
    site_name = models.CharField(max_length=100)
    url = models.URLField('site URL')

    def __str__(self): #toString 역할
        return '이름: ' +self.site_name + \
            ', 주소: ' + self.url
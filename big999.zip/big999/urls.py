from django.contrib import admin
from django.urls import path, include

import accounts.urls ##urls 안잡히면 이거 못가져와
import insta.urls
import insta.views

urlpatterns = [
    path('', insta.views.selectAll, name="start"), #그냥 로컬호스트 들어오면, 콤마 이후 경로로 보낼께
    path('admin/', admin.site.urls),
    path('insta/', include(insta.urls)), #include(insta.urls) 인스타 패키지 경로로 바꿔주자. 얘는 Common 한 애니깐
    path('accounts/', include(accounts.urls))
]

from django.conf.urls.static import static
from django.conf import settings

#사진출력 ==>> url로 바꿔놓은거임. 그래서 이미지를 가져올 수 있는 것임.
#이걸 바깥쪽 urls.py 에 넣어줘야 app마다 다 따로 따로 적용되서
#임포트 시킴. media랑 static이랑 연결시켜줌.
urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT) #2-2 MEDIA_ROOT을 읽어서, url 패턴으로 추가해줌.
# urlpatterns = utrlppatenrs + static 을 의미.
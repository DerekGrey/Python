from django.contrib.auth.models import User
from django.db import models

# Create your models here.

class Photo(models.Model):
    author = models.ForeignKey(User, on_delete=models.CASCADE, related_name='user_photos') #온딜리트는 DB 값 원본이 삭제되었을 때, 다른거로 처리한다. =CASCADE 그냥 지운다.
    photo = models.ImageField(upload_to='photos/%Y/%m/%d', default='photos/no_image.png') #이미지필드 means, 이미지 넣는다. -> upload_to는 값
    created = models.DateTimeField(auto_now_add=True) #insert 될 때 현재시각을 자동으로 넣어줘.
    updated = models.DateTimeField(auto_now=True) #동작처리할때 시간을 수정함.
    text = models.TextField(default='') #안넣으면 그냥 공백으로 넣으렴~


    #값을 가져올때 거꾸로 가져올 수 있는 내부클래스가 있음.
    #내부클래스 사용   
    class Meta: #메타데이터는 부가적 데이터
        ordering = ['-updated'] # - 는 거꾸로가져오렴
                                # 그냥 쓰면 오름차순으로 가져옴. 'updated' 는 상위클래스 updated를 의미함. = updated는 DB의 칼럼

    def __str__(self):
        return self.author.username + ' ' + \
               self.created.strftime('%Y-%m-%d, %H:%M:%S') + "," #스트림 포맷-> 시간을 내가 원하는 대로 포맷해서 가져옴, %x는 2자리로 만들어서 가져옴.
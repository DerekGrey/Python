"""big999 URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path

import insta.views

urlpatterns = [
    # insta/test
    path('test', insta.views.test, name='test'), #어드민 경로 지워줬다. 왜냐? 나는 insta 패키지경로로 온 도메인을 처리할거니깐.
    path('selectAll', insta.views.selectAll, name="selectAll"), #SelectALL로 요청들어왔을때 처리한다.
    path("selectOne/<int:pk>", insta.views.SelectOne.as_view(), name = "selectOne"), #애는 클래스로 지정해서. 앞글자 대문자
    #as_view()함수는 상속을 받아, 괄호안에걸 파라미터로도 바로 처리할 수 있음.
    #as_view(model.model) 뭐 이런식으로..? 흠..
    #함수니깐 대문자가 아니라 소문자 test로 처리됨. 클래스면 Test겠지
    path('upload/', insta.views.PhotoUploadView.as_view(), name='upload') #포토업로드뷰
]

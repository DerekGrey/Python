from django.contrib.auth.mixins import LoginRequiredMixin
from django.http import HttpResponse
from django.shortcuts import render, redirect

# Create your views here.
from django.views.generic import DetailView, CreateView

from insta.models import Photo


#함수랑 클래스 쓰는 경우
#클래스 : 통체로 넘기는 경우 일 때가 편해, 모델 지정해줘야함
#함수 : 함수는 변환 받은 변수를 '중간결과'를 처리해서 넘길때 편함

def test(request):
    return HttpResponse('i am test of insta!')


def me(request):
    return HttpResponse('I, my, Me ''/ ')

def selectAll(request): #함수는 무조건 Request 변수 넣어준다.
    list = Photo.objects.all() #장고의 문법-> Select ALL 모든걸 가져와, 모델명(Photo).objects(객체).all() 함수 모든 것!!
    #Photo만 바꿔준다. 모델의 클래스명만 바꿔줘
    return render(request, "insta/list.html", {"list" : list}) #템플릿으로 가지고온다. render -> 템플릿을 지정해준다.
    #insta/list.html 로 렌더링하여, 반환하여 보내준다. {"list" 키, lsit 값 딕셔너리 형태로 넘긴다}
    #request 객체 파라미터를, 렌더링하여 insta/list.html로 보내주는것인데, 그 값은 딕셔너리를 반환하는 것

class SelectOne(DetailView): #항상 import
        model = Photo
        template_name = "insta/selectOne.html"

class PhotoUploadView(CreateView): #업로드는 폼이 필요해요. cla
    model = Photo
    fields = ['photo', 'text']
    template_name = 'insta/upload.html'

    #Overwrite
    #업로드시 얘가 자동호출됨.
    def form_valid(self, form): #폼객체로 가져옴.
        form.instance.author_id = self.request.user.id #유저 테이블에 있는 id를 폼객체의 작가 id에 넣어줌.
        if form.is_valid():
            form.instance.save() #인서트문을 내부적으로 저장한다.
            return redirect('/insta/selectAll') #Success 시 일로 넘아가세요.
        else:
            return self.render_to_response({'form': form}) #유효하지 않은 값이 들어와있으면, 'form' 객체를 만들어서, 다시 form 으로 가세요.
    
class Dog:
#   멤버변수
    color = ''
    field = ''
#   멤버함수
    def bark(self):
        print('짖다')
    def tail(self):
        print("꼬리를 흔들다.")
    def __str__(self):
        return '색은 ' + self.color + ' 종은' + self.field

class Cat:
    name = ''
    age = 0


    #생성자, 초기화시켜줌
    def __init__(self, name, age):
        self.name = name
        self.age = age


    def punch(self):
        print('냥냥하다.')
    def __str__(self):
        return '이름은 ' + self.name + ' 나이는 ' + str(self.age)

if __name__ == '__main__':
    bokdol2 = Dog()
    bokdol2.field = '우리집'
    bokdol2.color = '흰색'
    print(bokdol2)
    print('------------')
    print(bokdol2.field)
    print(bokdol2.color)

    bokdol2.bark()
    bokdol2.tail()

    print('------여기부터는 고양이 영역--------')
    
    #생성자 있는 고양이
    cat = Cat('야옹이', 2) #객체 생성
    print(cat)


    cat.punch()
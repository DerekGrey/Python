class Car:
    #멤버변수
    color = ''
    gas = 0

    #생성자
    #color = None(default) // 만약에, 색깔은 넣기 싫다면
    #print(isinstance(tiger, Tiger))
    def __init__(self, color, gas):
         self.color = color
         self.gas = gas

    # 멤버함수
    def speed(self):
        print('달립니다.')
    def drive(self):
        print('운전합니다.')

    def __str__(self):
        return '자동차의 색은 ' + self.color + ' 그리고, 자동차의 남은 연료는 ' + str(self.gas) + 'km/h'

class Truck:
    #멤버 변수
    classification = ''
    price = 0

    #생성자

    def __init__(self, classification, price):
        self.classification = classification
        self.price = price


    #멤버 함수
    def corner(self):
        print("코너링을 돕니다.")
    def load(self):
        print("물건을 적재합니다.")

    def __str__(self):
        return '트럭의 종류는' + self.classification + ' 이며, 트럭의 가격은' + str(self.price) + '입니다.'

if __name__ == '__main__':
    car = Car('파란색',20) #객체 생성 순간부터 생성자는 바로 파라미터를 넣어줌
    print(car)
    car.speed()
    car.drive()
    print('---------')


    
    print('--------트럭존---------')
    truck = Truck('하늘색', 10000000)
    print(truck)
from 자동차.car import *


car = Car('스카이블루', 60)
print(car)

class My_truck(Truck):
    def corner(self):
        print("코너를 돕니다.")
    def __str__(self):
        return self.classification + "는 우리집 트럭차종이고," + str(self.price) + "는 우리집 트럭 가격입니다."

class My_car(Car):

    def drive(self):
        print("신나게 달림")
    def __str__(self):
        return self.color + " 는 우리집 차 색깔," + str(self.gas) + "km/h 만큼 갈 수 있는 거리임."
if __name__ == '__main__':
    home_truck = My_truck("1종 화물 트럭", 800000000)
    print(home_truck)

    home_car = My_car("black", 500)
    print(home_car)
    home_car.drive()



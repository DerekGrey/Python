import pandas as pd
import pandas_datareader as pdr
import yahoo_finance
# 회사명으로 주식 종목 코드를 획득할 수 있도록 하는 함수
def get_code(df, name):
    code = df.query("name=='{}'".format(name))['code'].to_string(index=False)
# 위와같이 code명을 가져오면 앞에 공백이 붙어있는 상황이 발생하여 앞뒤로 sript() 하여 공백 제거
    code = code.strip()
    return code
# excel 파일을 다운로드하는거와 동시에 pandas에 load하기
# 흔히 사용하는 df라는 변수는 data frame을 의미합니다.
code_df = pd.read_html('http://kind.krx.co.kr/corpgeneral/corpList.do?method=download', header=0)[0]
# data frame정리
code_df = code_df[['회사명', '종목코드']]
# data frame title 변경 '회사명' = name, 종목코드 = 'code'
code_df = code_df.rename(columns={'회사명': 'name', '종목코드': 'code'})
# 종목코드는 6자리로 구분되기때문에 0을 채워 6자리로 변경
code_df.code = code_df.code.map('{:06d}'.format)
# ex) 삼성전자의의 코드를 구해보겠습니다.
code = get_code(code_df, '삼성전자')
# yahoo의 주식 데이터 종목은 코스피는 .KS, 코스닥은 .KQ가 붙습니다.
# 삼성전자의 경우 코스피에 상장되어있기때문에 '종목코드.KS'로 처리하도록 한다.
code = code + '.KS'
# get_data_yahoo API를 통해서 yahho finance의 주식 종목 데이터를 가져온다.
df = pdr.get_data_yahoo(code)

# import pandas_datareader as pdr
#
# df = pdr.DataReader('주식종목코드', 'yahoo')
# df = pdr.get_data_yahoo('주식 종목코드')
#
# from datetime import datetime
#
# start = datetime(2018,1,1)
# end = datetime(2019,12,31)
#
# df = pdr.DataReader('주식 종목코드', 'yahoo', start, end)
# df = pdr.get_data_yahoo('주식 종목코드', start, end)
from yahoo_finance import Share
import pandas as pd

#
# samsung = Share('005930.KS')
# samsung.get_info()
# {'CompanyName': None,
#  'end': '2016-07-10',
#  'start': '2000-01-04',
#  'symbol': '005930.KS'}
#
# samsung.get_historical('2016-07-04','2016-07-08')

# from pandas_datareader import data
# import matplotlib.pyplot as plt
# import pandas as pd
#
# start_date = '2020-05-10'
# end_date = '2020-05-28'
# google_data = data.DataReader('GOOGLE', 'Yahoo', start_date, end_date)
# google_data.head(9)
#
# google_data['CLOSE'].plot()
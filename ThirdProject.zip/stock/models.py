from django.db import models

# Create your models here.


class Stock(models.Model):
    id = models.CharField(max_length=100, primary_key=True)  # 상품 ID
    product_name = models.CharField(max_length=100)  # 주식 상품명
    date = models.DateTimeField(auto_now=True)  # 현재날짜
    high_price = models.CharField(max_length=100, default='')  # 고가
    low_price = models.CharField(max_length=100, default='')  # 저가
    now_price = models.CharField(max_length=100, default='')  # 현재가

    def __str__(self):
        return '상품 ID : ' + self.id + ' ' + \
               '주식상품명 : ' + self.product_name + ' ' + \
               '기준 날짜 : ' + self.date('%Y-%m-%d, %H:%M:%S') + "," + \
               '고가 : ' + self.high_price + ' ' + \
               '저가 : ' + self.low_price + ' ' + \
               '현재가 : ' + self.now_price + ' '
